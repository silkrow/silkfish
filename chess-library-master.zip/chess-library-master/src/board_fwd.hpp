#pragma once

namespace chess {
class Board;
}  // namespace chess
